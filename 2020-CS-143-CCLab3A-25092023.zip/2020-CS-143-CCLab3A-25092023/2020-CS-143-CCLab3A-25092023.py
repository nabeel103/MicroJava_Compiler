import threading
import time
import queue
#define queue
shared_buffer = queue.Queue()
#read file by setting the buffer size to 100
def readingFileContent(path, bufferSize):
    with open(file = path, mode= "rb") as f:
        while True:
            content = f.read(bufferSize)
            if not content:
                break
            #decode the bytes-like string into a regular string using the decode method with 'utf-8' encoding
            decoded_string = content.decode('utf-8')
            #store the regular string in shared_buffer (queue in our case)
            shared_buffer.put(decoded_string)
            time.sleep(1)
    #empty the shared buffer (queue)
    shared_buffer.put(None)
    
#get string stored in queue to split words by removing space or other character such as \n
def processData():
    while True:

        #start processing
        #shared_buffer (queue) serves as an intermediate storage for the content read from the file. It allows the reading and processing of data here
        getString = shared_buffer.get()
        #if the shared buffer contains zero entry it'll break the loop and stops the overall program execution
        if getString is None:
            break
        words = getString.strip().split()
        #Output the list of words obtained by splitting the strings stored in 'shared_buffer' after reading from the file with a buffer size of 100 
        print("The output of processing string is: ", words)
        time.sleep(1)
#main___block
#Enter the file path
print("Enter the file path: ")
filePath = input()
#Enter the required buffer size
print("Enter the required buffer size: ")
buffer_size = input()
reader_thread = threading.Thread(target= readingFileContent, args=(filePath, int(buffer_size)))
processor_thread = threading.Thread(target= processData)
reader_thread.start()
processor_thread.start()
