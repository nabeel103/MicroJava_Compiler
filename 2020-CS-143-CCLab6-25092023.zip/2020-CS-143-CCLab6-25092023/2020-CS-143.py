keyword = ['if']
operator = ['and', 'or', 'mod', 'div']


def read_and_split(file_path):
    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()
            words = [word for line in lines for word in line.split()]
            return words
    except FileNotFoundError:
        print(f"File not found: {file_path}")
        return None
    except Exception as e:
        print(f"An error occurred: {e}")
        return None


file_path = "D:\\Semester 7\\CC_Lab\\2020-CS-143-CCLab6-25092023\\file.txt"
result = read_and_split(file_path)
print(result)


def getNextCharacter(i, word):
    try:
        if i == 0:
            return word[i]
        else:
            return word[i]
    except:
        return False


def GetNextToken(result):
    for word in result:
        while (1):
            i = 0
            ch = getNextCharacter(i, word)
            if ch == '<':
                i = i+1
                ch = getNextCharacter(i, word)
                if ch == '=':
                    print("Return LE")
                    break
                elif ch == '>':
                    print("Return NE")
                    break
                elif ch == False:
                    print("Return LT")
                    break
                else:
                    print("Dead end")
                    break
            elif ch == '>':
                i = i+1
                ch = getNextCharacter(i, word)
                if ch == '=':
                    print("Return GE")
                    break
                elif ch == False:
                    print("Return GT")
                    break
                else:
                    print("Dead end")
                    break
            elif ch.isalpha():
                i = i + 1
                flag = False
                ch = getNextCharacter(i, word)
                try:
                    while (ch.isalpha() or ch.isdigit()):
                        i = i+1
                        ch = getNextCharacter(i, word)

                except:
                    flag = True
                    if ch == False:
                        if word in keyword:
                            print(f"keyword {word}")
                            break
                        elif word in operator:
                            print(f"operator {word}")
                            break
                        else:
                            print(f"variable {word}")
                            break
                    else:
                        print("Dead end")
                        break
                if not flag == True:
                    print("Dead end")
                    break

            elif ch == ':':
                i = i + 1
                ch = getNextCharacter(i, word)
                if ch == '=':
                    print("Assignment operator :=")
                    break
                else:
                    print("Dead end")
                    break
            elif ch.isdigit():
                flag = False
                try:
                    i = i + 1
                    ch = getNextCharacter(i, word)
                    while ((ch.isdigit()) and (not (ch.isalpha()))):
                        i = i + 1
                        ch = getNextCharacter(i, word)
                        if ch == '.':
                            i = i + 1
                            ch = getNextCharacter(i, word)
                            while (ch.isdigit()):
                                i = i + 1
                                ch = getNextCharacter(i, word)

                        elif ch.lower() == 'e':
                            i = i + 1
                            ch = getNextCharacter(i, word)
                            if ch == '-' or ch == '+':
                                i = i + 1
                                ch = getNextCharacter(i, word)
                                while (ch.isdigit()):
                                    i = i + 1
                                    ch = getNextCharacter(i, word)

                    if ch == '.':
                        i = i + 1
                        ch = getNextCharacter(i, word)
                        while (ch.isdigit()):
                            i = i + 1
                            ch = getNextCharacter(i, word)

                    elif ch.lower() == 'e':
                        i = i + 1
                        ch = getNextCharacter(i, word)
                        if ch == '-' or ch == '+':
                            i = i + 1
                            ch = getNextCharacter(i, word)
                            while (ch.isdigit()):
                                i = i + 1
                                ch = getNextCharacter(i, word)
                except:
                    flag = True
                    if ch == False:
                        print(f"number {word}")
                        break
                    else:
                        print("Dead end")
                        break
                if not flag == True:
                    print("Dead end")
                    break

            elif ch == '{' or ch == '}' or ch == '+' or ch == '/' or ch == '-' or ch == '*' or ch == '=':
                i = i + 1
                ch = getNextCharacter(i, word)
                if ch == False:
                    print(
                        f"other operators or curly braces (open/close): {word}")
                    break
                else:
                    print("Dead end")
                    break
            else:
                break


token = GetNextToken(result)

def transition_table():
    